package com.example.birthday

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
