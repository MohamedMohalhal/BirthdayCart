import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}
 
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
 
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: BirthdayCart(),
    );
  }
}
class BirthdayCart extends StatelessWidget {
  const BirthdayCart({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(title: Text("Birthday Cart"),),
      body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
        children: [
           SizedBox(height: 50,),
          Center(
            child: Image.network("assets/download.jpeg",
            height : 300,
            width: double.infinity,
            ),
          ),
          SizedBox(height: 10,),
          Text("Happy Birthday !!")
        ],
      ),
    );
  }
}